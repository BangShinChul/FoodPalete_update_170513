package logic;

import org.springframework.stereotype.Service;

@Service
public class UpdateProfile {
	private String user_email;
	private String user_profile_img;
	
	public String getUser_email() {
		return user_email;
	}
	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}
	public String getUser_profile_img() {
		return user_profile_img;
	}
	public void setUser_profile_img(String user_profile_img) {
		this.user_profile_img = user_profile_img;
	}
	
}
