/**
 * facebook login javascript
 */

//Facebook SDK
//appId : 이것으로 페이스북 앱ID와 연동되어 제어함
 window.fbAsyncInit = function() {
    FB.init({
      appId      : '291928887917537',
      xfbml      : true,
      version    : 'v2.9'
    });
    FB.AppEvents.logPageView();
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "//connect.facebook.net/ko_KR/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
  
//변수 설정
var user_token;
var flag = 0;
var userId;
var userName;
var userBirthday;
var userEmail;
var userGender;
var logoutUserName;
var loginStatus;

//로그인
function checkStatus(){
	FB.getLoginStatus(function(response) {
		if (response.status === 'connected') {
			console.log(response.authResponse.accessToken);
			user_token = response.authResponse.accessToken;
			FB.api('/me','GET',{fields: 'name, email'},function(response) {
				userName = response.name;
				userEmail = response.email;
			    viewInfo();
			});
		}
	});
}

function loginFB(){
	alert("fb로그인 시작");
	console.log("fb로그인 시작");
	FB.login(function(response){
		alert("test");
		console.log("페이스북상태 "+response.status);
		if(response.status == 'connected'){
			console.log("로그인성공");
			alert("페이스북 로그인 성공!");
			alert("페이스북 로그인 상태 : connected");
			user_token = response.authResponse.accessToken;
			getFacebookUserInfo();
//			setInterval(function(){
//				if(flag == 1){
//					viewInfo();
//				}
//			},500);
		}else if(response.status='not_authorized'){
			alert("페이스북 로그인 상태 : not_authorized");
//			console.log("로그인성공");
//			user_token = response.authResponse.accessToken;
//			getFacebookUserInfo();
//			setInterval(function(){
//				if(flag == 1){
//					viewInfo();
//				}
//			},500);
		}
	},{scope : 'public_profile, email'});
}

function getFacebookUserInfo(){
	FB.api('/me','GET',{fields: 'name, email'},function(response) {
		userName = response.name;
		userEmail = response.email;
		alert("name:"+userName+" / email:"+userEmail);
		viewInfo();
	});
}

//로그아웃
function logoutFB(){
	//logoutUserName = userName;
	FB.logout(function(response){
	});
	
}

//쿠기로드
function getCookie(){
	FB.Event.subscribe('auth.statusChange', function(response) {
		document.write("토큰 : " + user_token+"<br/>");
		//document.getElementById("btn_login").value = logoutUserName+"님 다시 로그인";
		loginStatus = 1;
	
	});
}

//자동 Submit
function viewInfo(){
	console.log("이름값 : "+userName);
	flag = 0;
	var fb_name = document.getElementById("fb_name");
	var fb_email = document.getElementById("fb_email");
	var fb_form = document.getElementById("fb_form");
	fb_name.setAttribute("value", userName);
	fb_email.setAttribute("value", userEmail);
	fb_form.submit();
}

//로그아웃 로그
function logoutView(){
	document.write("토큰 : " + user_token+"<br/>");
	document.write("로그아웃 이름 :" + logoutUserName+"<br/>");
}
